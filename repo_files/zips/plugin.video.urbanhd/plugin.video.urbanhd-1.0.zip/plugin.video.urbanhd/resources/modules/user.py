import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnVyYmFuaGQ=')

name = b.b64decode('VVJCYW4tSEQ=')

host = b.b64decode('aHR0cDovL3N0b3BwaW5nZnJvc3QuZGRucy5uZXQ=')

port = b.b64decode('NDU0NQ==')